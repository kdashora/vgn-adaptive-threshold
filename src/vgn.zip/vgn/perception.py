from math import cos, sin
import time

import numpy as np
import open3d as o3d

from vgn.utils.transform import Transform


class CameraIntrinsic(object):
    """Intrinsic parameters of a pinhole camera model.

    Attributes:
        width (int): The width in pixels of the camera.
        height(int): The height in pixels of the camera.
        K: The intrinsic camera matrix.
    """

    def __init__(self, width, height, fx, fy, cx, cy):
        self.width = width
        self.height = height
        self.K = np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]])

    @property
    def fx(self):
        return self.K[0, 0]

    @property
    def fy(self):
        return self.K[1, 1]

    @property
    def cx(self):
        return self.K[0, 2]

    @property
    def cy(self):
        return self.K[1, 2]

    def to_dict(self):
        """Serialize intrinsic parameters to a dict object."""
        data = {
            "width": self.width,
            "height": self.height,
            "K": self.K.flatten().tolist(),
        }
        return data

    @classmethod
    def from_dict(cls, data):
        """Deserialize intrinsic parameters from a dict object."""
        intrinsic = cls(
            width=data["width"],
            height=data["height"],
            fx=data["K"][0],
            fy=data["K"][4],
            cx=data["K"][2],
            cy=data["K"][5],
        )
        return intrinsic


class TSDFVolume(object):
    """Integration of multiple depth images using a TSDF."""

    def __init__(self, size, resolution):
        self.size = size
        self.resolution = resolution
        self.voxel_size = self.size / self.resolution
        self.sdf_trunc = 4 * self.voxel_size

        self._volume = o3d.pipelines.integration.UniformTSDFVolume(
            length=self.size,
            resolution=self.resolution,
            sdf_trunc=self.sdf_trunc,
            color_type=o3d.pipelines.integration.TSDFVolumeColorType.NoColor,
        )

    def integrate(self, depth_img, intrinsic, extrinsic):
        """
        Args:
            depth_img: The depth image.
            intrinsic: The intrinsic parameters of a pinhole camera model.
            extrinsic: The transform from the TSDF to camera coordinates, T_eye_task.
        """
        rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
            o3d.geometry.Image(np.empty_like(depth_img)),
            o3d.geometry.Image(depth_img),
            depth_scale=1.0,
            depth_trunc=2.0,
            convert_rgb_to_intensity=False,
        )

        intrinsic = o3d.camera.PinholeCameraIntrinsic(
            width=intrinsic.width,
            height=intrinsic.height,
            fx=intrinsic.fx,
            fy=intrinsic.fy,
            cx=intrinsic.cx,
            cy=intrinsic.cy,
        )

        extrinsic = extrinsic.as_matrix()

        self._volume.integrate(rgbd, intrinsic, extrinsic)

    def get_grid(self):
        cloud = self._volume.extract_voxel_point_cloud()
        points = np.asarray(cloud.points)
        distances = np.asarray(cloud.colors)[:, [0]]
        grid = np.zeros((1, 40, 40, 40), dtype=np.float32)
        for idx, point in enumerate(points):
            i, j, k = np.floor(point / self.voxel_size).astype(int)
            grid[0, i, j, k] = distances[idx]
        return grid

    def get_cloud(self):
        return self._volume.extract_point_cloud()


def create_tsdf(size, resolution, depth_imgs, intrinsic, extrinsics):
    tsdf = TSDFVolume(size, resolution)
    for i in range(depth_imgs.shape[0]):
        extrinsic = Transform.from_list(extrinsics[i])
        tsdf.integrate(depth_imgs[i], intrinsic, extrinsic)
    return tsdf


def create_color_voxel_grid(size, resolution, rgb_imgs, intrinsic, extrinsics):
    """Project RGB images into a 3D voxel grid aligned with the TSDF.

    RGB-D fusion: for each voxel center, we project it into every camera
    view, sample the pixel color, and average across all visible views.
    The result is a (3, resolution, resolution, resolution) float32 array
    with values in [0, 1] representing R, G, B channels.

    Args:
        size:       physical size of the workspace cube (metres)
        resolution: number of voxels per side (e.g. 40)
        rgb_imgs:   (N, H, W, 3) uint8 array of RGB images
        intrinsic:  CameraIntrinsic object
        extrinsics: (N, 7) float32 array of camera extrinsics

    Returns:
        color_grid: (3, resolution, resolution, resolution) float32, RGB in [0,1]
    """
    voxel_size = size / resolution
    color_grid = np.zeros((3, resolution, resolution, resolution), dtype=np.float32)
    count_grid = np.zeros((resolution, resolution, resolution), dtype=np.float32)

    # Build voxel center coordinates in world space — vectorized (N_voxels, 3)
    idx_i, idx_j, idx_k = np.meshgrid(
        np.arange(resolution),
        np.arange(resolution),
        np.arange(resolution),
        indexing="ij",
    )
    # Voxel centers: offset by 0.5 so we sample the middle of each voxel
    voxel_centers = np.stack(
        [
            (idx_i.ravel() + 0.5) * voxel_size,
            (idx_j.ravel() + 0.5) * voxel_size,
            (idx_k.ravel() + 0.5) * voxel_size,
        ],
        axis=1,
    )  # shape (resolution^3, 3)

    K = intrinsic.K  # 3x3 camera matrix

    for img_idx in range(len(rgb_imgs)):
        rgb   = rgb_imgs[img_idx]          # (H, W, 3) uint8
        T     = Transform.from_list(extrinsics[img_idx]).as_matrix()  # 4x4

        # Homogeneous voxel centers → camera space
        ones    = np.ones((len(voxel_centers), 1), dtype=np.float32)
        pts_h   = np.hstack([voxel_centers, ones])          # (N, 4)
        pts_cam = (T @ pts_h.T).T                           # (N, 4)

        # Only keep points in front of the camera
        valid_depth = pts_cam[:, 2] > 0

        # Project to image coordinates
        u = K[0, 0] * pts_cam[:, 0] / np.where(pts_cam[:, 2] != 0, pts_cam[:, 2], 1) + K[0, 2]
        v = K[1, 1] * pts_cam[:, 1] / np.where(pts_cam[:, 2] != 0, pts_cam[:, 2], 1) + K[1, 2]

        u_int = np.round(u).astype(int)
        v_int = np.round(v).astype(int)

        # Filter: in-bounds pixels only
        h, w   = rgb.shape[:2]
        in_img = (u_int >= 0) & (u_int < w) & (v_int >= 0) & (v_int < h)
        valid  = valid_depth & in_img

        # Voxel indices for valid projections
        vi = idx_i.ravel()[valid]
        vj = idx_j.ravel()[valid]
        vk = idx_k.ravel()[valid]

        # Sample pixel colors — normalise uint8 → float [0, 1]
        pixel_rgb = rgb[v_int[valid], u_int[valid], :3].astype(np.float32) / 255.0

        # Accumulate color and count (for averaging later)
        np.add.at(color_grid[0], (vi, vj, vk), pixel_rgb[:, 0])
        np.add.at(color_grid[1], (vi, vj, vk), pixel_rgb[:, 1])
        np.add.at(color_grid[2], (vi, vj, vk), pixel_rgb[:, 2])
        np.add.at(count_grid,    (vi, vj, vk), 1.0)

    # Average over all contributing views
    observed = count_grid > 0
    for c in range(3):
        color_grid[c][observed] /= count_grid[observed]

    return color_grid


def camera_on_sphere(origin, radius, theta, phi):
    eye = np.r_[
        radius * sin(theta) * cos(phi),
        radius * sin(theta) * sin(phi),
        radius * cos(theta),
    ]
    target = np.array([0.0, 0.0, 0.0])
    up = np.array([0.0, 0.0, 1.0])  # this breaks when looking straight down
    return Transform.look_at(eye, target, up) * origin.inverse()
